#!/usr/bin/env python3
"""Rebuild the minified loader that is embedded in arcager.py.   (Maintainers only.)

Users never need this: `arcager --minify` uses the minified loader that ships inside
arcager.py, so it works without Terser. Run this script after you EDIT the loader
(JS_RUNTIME in arcager.py), which needs Terser:  npm install -g terser

    python scripts/build_runtime.py           rebuild and write the block into arcager.py
    python scripts/build_runtime.py --check   change nothing; exit 1 if the embedded copy is stale

The embedded copy carries the SHA-256 of the loader source it was built from. If the
source changes and this script is not re-run, Arcager notices (it never ships a stale
copy) and the test-suite fails with a reminder.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARCAGER = ROOT / "arcager.py"
BLOCK = re.compile(r"(# BEGIN GENERATED: runtime-min[^\n]*\n)(.*?)(# END GENERATED: runtime-min)", re.S)
TERSER_ARGS = ["--compress", "passes=2,unsafe_arrows=true,toplevel=true", "--mangle", "toplevel"]


def load():
    spec = importlib.util.spec_from_file_location("arcager_build_rt", ARCAGER)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["arcager_build_rt"] = mod
    spec.loader.exec_module(mod)
    return mod


def terser(js: str) -> str:
    exe = shutil.which("terser")
    if not exe:
        raise SystemExit("error: Terser is required to rebuild the loader (npm install -g terser). "
                         "Users do not need it: arcager --minify works without it.")
    r = subprocess.run([exe, *TERSER_ARGS], input=js.encode("utf-8"), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if r.returncode != 0:
        raise SystemExit("error: Terser failed:\n" + r.stderr.decode("utf-8", "replace"))
    return r.stdout.decode("utf-8")


def syntax_check(js: str, label: str) -> None:
    node = shutil.which("node")
    if not node:
        print(f"  (node not found: skipped the syntax check of the {label} loader)")
        return
    with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False, encoding="utf-8") as f:
        f.write(js)
    r = subprocess.run([node, "--check", f.name], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    Path(f.name).unlink(missing_ok=True)
    if r.returncode != 0:
        raise SystemExit(f"error: the minified {label} loader is not valid JavaScript:\n" + r.stderr.decode("utf-8", "replace"))


def main() -> int:
    ap = argparse.ArgumentParser(description="Rebuild the minified loader embedded in arcager.py (maintainers only).")
    ap.add_argument("--check", action="store_true", help="only report whether the embedded copy is current")
    ns = ap.parse_args()
    mod = load()
    current = mod.runtime_is_prebuilt()
    if ns.check:
        if current:
            print("The embedded minified loader is up to date.")
            return 0
        print("The embedded minified loader is OUT OF DATE.\nFix: python scripts/build_runtime.py   (needs Terser)", file=sys.stderr)
        return 1
    digest = hashlib.sha256(mod.JS_RUNTIME.encode("utf-8")).hexdigest()
    built = {}
    for encrypted, label in ((False, "plain"), (True, "encrypted")):
        built[encrypted] = terser(mod.runtime_source(encrypted))
        syntax_check(built[encrypted], label)
        print(f"  {label:9} loader: {len(mod.runtime_source(encrypted).encode())} -> {len(built[encrypted].encode())} bytes")
    body = (f'RUNTIME_MIN_SOURCE_SHA256 = "{digest}"\n'
            f"RUNTIME_MIN = {{\n    False: {built[False]!r},\n    True: {built[True]!r},\n}}\n")
    text = ARCAGER.read_text(encoding="utf-8")
    if not BLOCK.search(text):
        raise SystemExit("error: the 'GENERATED: runtime-min' markers are missing from arcager.py")
    ARCAGER.write_text(BLOCK.sub(lambda m: m.group(1) + body + m.group(3), text, count=1), encoding="utf-8")
    print("Updated arcager.py. Run the tests: python scripts/run_tests.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
