Arcager 4.3 documentation
==========================

The public entry point is ../README.md.

Architecture
------------
See ARCHITECTURE.md for the logical/physical resource model, stream layout,
deduplication, conversion policy, encryption boundary and runtime contract.

Testing
-------
See TESTING.md for the regression strategy, benchmark philosophy and the
current local validation record. Cross-platform execution is covered by the
GitHub Actions matrix in ../.github/workflows/ci.yml.

Arcager needs Python 3.8+ and three packages, installed in one step
(python -m pip install -r requirements.txt, or: python arcager.py --install-deps):
cryptography (encryption), brotli (-c brotli) and Pillow (lossy conversion and
metadata stripping). Missing packages never produce a silent failure: Arcager
says which feature needs which package and how to install it. Minification of
the loader is built in and needs no extra tool.
